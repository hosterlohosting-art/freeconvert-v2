try {
    $url = "https://github.com/hosterlohosting-art/freeconvert-v2/archive/refs/heads/main.zip"
    Write-Host "Trying to download $url..."
    Invoke-WebRequest -Uri $url -OutFile "repo.zip" -ErrorAction Stop
} catch {
    try {
        $url = "https://github.com/hosterlohosting-art/freeconvert-v2/archive/refs/heads/master.zip"
        Write-Host "Trying to download $url..."
        Invoke-WebRequest -Uri $url -OutFile "repo.zip" -ErrorAction Stop
    } catch {
        Write-Error "Failed to download from both main and master branches."
        exit 1
    }
}

if (Test-Path "repo.zip") {
    Write-Host "Extracting archive..."
    Expand-Archive -Path "repo.zip" -DestinationPath . -Force
    Remove-Item "repo.zip" -Force
    
    $dir = Get-ChildItem -Directory | Where-Object { $_.Name -like "freeconvert-v2-*" }
    if ($dir) {
        Write-Host "Moving files from $($dir.FullName)..."
        # Move-Item handles moving files and folders from inside $dir to the current directory
        Get-ChildItem -Path $dir.FullName | ForEach-Object {
            Move-Item -Path $_.FullName -Destination . -Force
        }
        Remove-Item -Path $dir.FullName -Recurse -Force
        Write-Host "Successfully extracted and cleaned up."
    } else {
        Write-Error "Could not find extracted directory freeconvert-v2-*"
    }
}
